$(function() {
  var client = ZAFClient.init();
  client.invoke('resize', { width: '400px', height: '120px' });

  client.get('ticket.requester.id').then(function(data){ // gets data from the UI asynchronously
  	var user_id = data['ticket.requester.id'];
  	console.log("Requester ID: " + user_id); // gets the user id of the requester of the ticket currently open in the agent interface.

  	requestUserInfo(client, user_id); // HTTP request to the Users API in the Zendesk REST API.
  });

});

function showInfo(data) {
  var requester_data = {
    'name': data.user.name,
    'tags': data.user.tags,
    'created_at': formatDate(data.user.created_at),
    'last_login_at': formatDate(data.user.last_login_at)
  };

  var source = $("#requester-template").html();
  var template = Handlebars.compile(source);
  var html = template(requester_data);
  $("#content").html(html);
}

function showError() {
  var error_data = {
    'status': response.status,
    'statusText': response.statusText
  };
  var source = $("#error-template").html();
  var template = Handlebars.compile(source);
  var html = template(error_data);
  $("#content").html(html);
}


function requestUserInfo(client, id) {
  var settings = {
    url: '/api/v2/users/'+ id +'.json',
    type: 'GET',
    dataType: 'json',
  };

  client.request(settings).then( // to make HTTP requests to external APIs
    function(data){
      showInfo(data);
    }, 
    function(response){
      showError(response);
    }
  );
}

function formatDate(date) {
  var cdate = new Date(date);
  var options = {
    year: "numeric",
    month: "short",
    day: "numeric"
  };
  date = cdate.toLocaleDateString("en-us", options);
  return date;
}